#include <iostream>

using namespace std;
double result=0 , i=-1 ,error =0 ;
double power(double y , double p){
    if(p==0.0){
        return 1;}
        return y*power(y,p-1);}
double factorial(double z){
    if(z>1){
        return z* factorial(z-1);}
        else{return 1;}
    }
double abslute (double n){
    if(n<0){return (-n) ;}
    else{return n ;}
}
double sin(double k){
   i=i+1;
     error=((power((-1),i))*(power(k , (2*i)+1)))/factorial((2*i)+1);
     if(abslute(error)<0.00001){return result;}
     result=result+error;
     return sin(k);


}
double cos(double x){
    i=i+1;
    error=((power((-1),i))*(power(x , (2*i))))/factorial((2*i));
    if(abslute(error)<0.00001){return result;}
    result=result+error;
     return cos(x);

}
double exp(double m){
    i=i+1;
    error=(power(m , i))/factorial(i);
    if(abslute(error)<0.00001){return result;}
    result=result+error;
     return exp(m);
}
double lnn(double l){
    i=i+1;
    if(i>0){return lnn(l);}
    else{
    error=((power((-1),(i+1))*(power(l , i)))/i);
     if(error<0.00000000001){return result;}
    result=result+error;
     return lnn(l);}


}
double tan(double w){
    i=i+1;
    error=((power((-1),i))*(power(w , (2*i)+1)))/((2*i)+1);
     if(abslute(error)<0.00001){return result;}
    result=result+error;
     return tan(w);

}


int main()
{
    int no;
    double x;
    cout<<"what do you want to calculate?"<<endl<<"1-sin(x)"<<endl<<"2-cos(x)"<<endl<<"3-e*x"<<endl<<"4-ln(1+x)"<<endl<<"5-tan(-1)(x)"<<endl;
    cin>>no;
    const double pi=3.14159265359;
    if(no==1){

            cout<<"The number of x =";
            cin>>x;
            cout<<endl;

        cout<<   sin((x*pi)/180);


    }
    else if(no==2){
            cout<<"The number of x =";
            cin>>x;
            cout<<endl;
            cout<<   cos((x*pi)/180);


    }
    else if(no==3){

            cout<<"The number of x =";
            cin>>x;
            cout<<endl;
            cout<<   exp(x);



    }
    else if(no==4){
            cout<<"The number of x =";
            cin>>x;
            cout<<endl;
            cout<<lnn(x+1);


    }
    else if(no==5){
            cout<<"The number of x =";
            cin>>x;
            cout<<endl;
        cout<<tan(x);
    }
    else{
        return 0;
    }

    return 0;
}
